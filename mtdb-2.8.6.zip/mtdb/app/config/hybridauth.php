<?php
return array(	
	"base_url"   => url() . '/social/auth',
	"providers"  => array (
		"Google"     => array (
			"enabled"    => true,
			"keys"       => array ( "id" => getenv('GOOGLE_ID'), "secret" => getenv('GOOGLE_SECRET') ),
			"scope"      => "https://www.googleapis.com/auth/userinfo.profile ".
                            "https://www.googleapis.com/auth/userinfo.email"   ,
			),
		"Facebook"   => array (
			"enabled"    => true,
			"keys"       => array ( "id" => getenv('FACEBOOK_ID'), "secret" => getenv('FACEBOOK_SECRET') ),
			'scope'      =>  'email',
			),
		"Twitter"    => array (
			"enabled"    => true,
			"keys"       => array ( "key" => getenv('TWITTER_ID'), "secret" => getenv('TWITTER_SECRET') )
			)
	),
);