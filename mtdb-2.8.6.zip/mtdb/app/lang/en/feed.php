<?php return array(

	'nowInTheatersDesc' => 'Movies Currently PLaying In Theaters',
	'newsDesc'          => 'Latest News',
	'newsUrl'           => 'news',
	'theatersUrl'       => 'now-in-theaters',
	'feed'              => 'feed',


	);